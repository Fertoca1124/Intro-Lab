﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_FDTR_1053723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo soy Fernando");
            
            Console.WriteLine("Hola mundo");
            Console.WriteLine("Fernando");

            /*La diferencia es que WriteLine separa las palabras que se ecribieron dentro del parantesis. Sin embargo, Write deja todas las palabras juntas*/

            Console.Write("Hola mundo");
            Console.Write("Soy Fernando");
            Console.WriteLine();
            Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Soy" + Nombre);

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Soy" + Nombre);
            Console.ReadKey();
          


        }

    }
}
