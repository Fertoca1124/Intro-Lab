﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_FDTR_1053723
{
    internal class TrianguloRectangulo
    {
        private double catetoA;
        private double anguloOpuestoA;

        public TrianguloRectangulo(double catetoA, double anguloOpuestoA)
        {
            this.catetoA = catetoA;
            this.anguloOpuestoA = anguloOpuestoA;
        }

        public double ObtenerCatetoA()
        {
            return catetoA;
        }

        public double ObtenerCatetoB()
        {
            double catetoB = catetoA * Math.Tan(anguloOpuestoA * (Math.PI / 180));
            return catetoB;
        }

        public double ObtenerHipotenusa()
        {
            double hipotenusa = catetoA / Math.Cos(anguloOpuestoA * (Math.PI / 180));
            return hipotenusa;
        }

        public double ObtenerAnguloOpuestoA()
        {
            return anguloOpuestoA;
        }

        public double ObtenerAnguloOpuestoB()
        {
            return 90 - anguloOpuestoA;
        }

        public double ObtenerArea()
        {
            double area = 0.5 * catetoA * ObtenerCatetoB();
            return Math.Round(area, 3);
        }
    }
}
