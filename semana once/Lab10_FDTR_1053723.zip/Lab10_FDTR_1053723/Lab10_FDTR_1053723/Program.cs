﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_FDTR_1053723
{
    internal class Programa
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio del círculo:");
            double radio = Convert.ToDouble(Console.ReadLine());

            double perimetro = 0;
            double area = 0;
            double volumen = 0;

            Circulo objCirculo = new Circulo(radio);
            objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

            Console.WriteLine("Perímetro del círculo: " + perimetro);
            Console.WriteLine("Área del círculo: " + area);
            Console.WriteLine("Volumen del circulo: " + volumen);


            double catetoA, anguloOpuestoA;

            Console.Write("Introduce la longitud del cateto del triángulo (en metros): ");
            catetoA = Convert.ToDouble(Console.ReadLine());

            Console.Write("Introduce el ángulo opuesto al cateto (en grados): ");
            anguloOpuestoA = Convert.ToDouble(Console.ReadLine());

            
            TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

            
            Console.WriteLine("Cateto A: " + objTriangulo.ObtenerCatetoA() + "metros");
            Console.WriteLine("Cateto B: " + objTriangulo.ObtenerCatetoB() + "metros");
            Console.WriteLine("Hipotenusa: " + objTriangulo.ObtenerHipotenusa() + "metros");
            Console.WriteLine("Ángulo opuesto de A: " + objTriangulo.ObtenerAnguloOpuestoA() + "grados");
            Console.WriteLine("Ángulo opuesto de B: " + objTriangulo.ObtenerAnguloOpuestoB() + "grados");
            Console.WriteLine("Área del triángulo: " + objTriangulo.ObtenerArea() + "metros cuadrados");

            Console.ReadKey();
        }

     }



}

              
            
       




       




