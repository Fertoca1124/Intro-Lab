﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_FDTR_1053723
{
    internal class Circulo
    {
        private double radio;       
        public Circulo(double radio)
            {
                this.radio = radio;
            }

            private double ObtenerPerimetro()
            {
                return 2 * Math.PI * radio;
            }

            private double ObtenerArea()
            {
                return Math.PI * radio * radio;
            }

            public double ObtenerVolumen()
            {

            return (4 * Math.PI * radio * radio * radio) / 3;
            }

            public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
            {
                unPerimetro = ObtenerPerimetro();
                unArea = ObtenerArea();
                unVolumen = ObtenerVolumen();
            }
        }

        
}
