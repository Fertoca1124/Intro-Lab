﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_FDTR_1053723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");

            string sNombre;
            string sEdad;
            string sCarrera;
            string sCarné;

            Console.WriteLine("Ingresar su nombre, edad, carrera y carné");
           
            sNombre = Console.ReadLine();
            sEdad = Console.ReadLine();
            sCarrera = Console.ReadLine();
            sCarné = Console.ReadLine();


            Console.WriteLine("soy " + sNombre + ",tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ". Mi número de carné es " + sCarné);
        
            Console.ReadKey();
        }
    }
}
