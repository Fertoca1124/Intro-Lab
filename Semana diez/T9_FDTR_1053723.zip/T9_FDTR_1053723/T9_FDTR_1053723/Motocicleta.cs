﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace T9_FDTR_1053723
{
    internal class Motocicleta
    {
        private int Modelo;
        private double Precio;
        private string Marca;
        private double Iva;

     
        public Motocicleta()
        {
            Modelo = 2019;
            Precio = 1000;
            Marca = "";
            Iva = 0.12;
        }

        public string MostrarDatos()
        {
            return "Modelo: " + Modelo + " Marca: " + Marca + " Precio: " + Precio + " IVA: " + Iva;
        }
        public void DefinirModelo(int modelo)
        {
            this.Modelo = modelo;
        }

        public void DefinirMarca(string marca)
        {
            this.Marca = marca;
        }
        public void DefinirPrecio(double precio)
        {
            this.Precio = precio;
        }
        public void DefinirIva(double iva)
        {
            if (iva >= 0.01 && iva <= 0.99)
            {
                this.Iva = iva;
            }
            else
            {
                Console.WriteLine("Porcentaje de IVA no válido.");
            }
        }
        public double PrecioSinIva()
        {
            return Precio;
        }

        public double PrecioConIva()
        {
            return Precio * (1 + Iva);
        }

        public double DevolverIva()
        {
            return Precio * Iva;
        }
    }
}

