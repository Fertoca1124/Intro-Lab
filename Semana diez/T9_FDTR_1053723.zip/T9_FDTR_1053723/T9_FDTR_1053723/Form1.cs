namespace T9_FDTR_1053723
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Motocicleta objMotocicleta = new Motocicleta();
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int modelo = Convert.ToInt32(txtbxModelo.Text);
            string marca = txtbxMarca.Text;
            double precio = Convert.ToDouble(txtbxprecio.Text);
            double iva = Convert.ToDouble(txtbxIva.Text);

            objMotocicleta.DefinirModelo(modelo);
            objMotocicleta.DefinirMarca(marca);
            objMotocicleta.DefinirPrecio(precio);
            objMotocicleta.DefinirIva(iva);

            lblDatos.Text = objMotocicleta.MostrarDatos();
            lblPrecioSinIva.Text = $"Precio sin IVA: {objMotocicleta.PrecioSinIva()}";
            lblPrecioConIva.Text = $"Precio con IVA: {objMotocicleta.PrecioConIva()}";
            lblMontoIva.Text = $"Monto del IVA: {objMotocicleta.DevolverIva()}";
        }
    }
}
