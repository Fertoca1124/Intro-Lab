﻿namespace T9_FDTR_1053723
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblModelo = new Label();
            txtbxModelo = new TextBox();
            lblMarca = new Label();
            txtbxMarca = new TextBox();
            lblprecio = new Label();
            txtbxprecio = new TextBox();
            lblIva = new Label();
            txtbxIva = new TextBox();
            btnCalcular = new Button();
            lblDatos = new Label();
            lblPrecioSinIva = new Label();
            lblPrecioConIva = new Label();
            lblMontoIva = new Label();
            SuspendLayout();
            // 
            // lblModelo
            // 
            lblModelo.AutoSize = true;
            lblModelo.Location = new Point(36, 27);
            lblModelo.Name = "lblModelo";
            lblModelo.Size = new Size(48, 15);
            lblModelo.TabIndex = 0;
            lblModelo.Text = "Modelo";
            // 
            // txtbxModelo
            // 
            txtbxModelo.Location = new Point(90, 24);
            txtbxModelo.Name = "txtbxModelo";
            txtbxModelo.Size = new Size(106, 23);
            txtbxModelo.TabIndex = 1;
            // 
            // lblMarca
            // 
            lblMarca.AutoSize = true;
            lblMarca.Location = new Point(36, 63);
            lblMarca.Name = "lblMarca";
            lblMarca.Size = new Size(40, 15);
            lblMarca.TabIndex = 2;
            lblMarca.Text = "Marca";
            // 
            // txtbxMarca
            // 
            txtbxMarca.Location = new Point(90, 60);
            txtbxMarca.Name = "txtbxMarca";
            txtbxMarca.Size = new Size(106, 23);
            txtbxMarca.TabIndex = 3;
            // 
            // lblprecio
            // 
            lblprecio.AutoSize = true;
            lblprecio.Location = new Point(36, 99);
            lblprecio.Name = "lblprecio";
            lblprecio.Size = new Size(40, 15);
            lblprecio.TabIndex = 4;
            lblprecio.Text = "Precio";
            // 
            // txtbxprecio
            // 
            txtbxprecio.Location = new Point(90, 96);
            txtbxprecio.Name = "txtbxprecio";
            txtbxprecio.Size = new Size(106, 23);
            txtbxprecio.TabIndex = 5;
            // 
            // lblIva
            // 
            lblIva.AutoSize = true;
            lblIva.Location = new Point(36, 134);
            lblIva.Name = "lblIva";
            lblIva.Size = new Size(22, 15);
            lblIva.TabIndex = 6;
            lblIva.Text = "Iva";
            // 
            // txtbxIva
            // 
            txtbxIva.Location = new Point(90, 134);
            txtbxIva.Name = "txtbxIva";
            txtbxIva.Size = new Size(106, 23);
            txtbxIva.TabIndex = 7;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(390, 33);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(110, 44);
            btnCalcular.TabIndex = 8;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblDatos
            // 
            lblDatos.AutoSize = true;
            lblDatos.Location = new Point(424, 96);
            lblDatos.Name = "lblDatos";
            lblDatos.Size = new Size(38, 15);
            lblDatos.TabIndex = 9;
            lblDatos.Text = "label1";
            // 
            // lblPrecioSinIva
            // 
            lblPrecioSinIva.AutoSize = true;
            lblPrecioSinIva.Location = new Point(424, 142);
            lblPrecioSinIva.Name = "lblPrecioSinIva";
            lblPrecioSinIva.Size = new Size(38, 15);
            lblPrecioSinIva.TabIndex = 10;
            lblPrecioSinIva.Text = "label2";
            // 
            // lblPrecioConIva
            // 
            lblPrecioConIva.AutoSize = true;
            lblPrecioConIva.Location = new Point(424, 188);
            lblPrecioConIva.Name = "lblPrecioConIva";
            lblPrecioConIva.Size = new Size(38, 15);
            lblPrecioConIva.TabIndex = 11;
            lblPrecioConIva.Text = "label3";
            // 
            // lblMontoIva
            // 
            lblMontoIva.AutoSize = true;
            lblMontoIva.Location = new Point(424, 232);
            lblMontoIva.Name = "lblMontoIva";
            lblMontoIva.Size = new Size(38, 15);
            lblMontoIva.TabIndex = 12;
            lblMontoIva.Text = "label4";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblMontoIva);
            Controls.Add(lblPrecioConIva);
            Controls.Add(lblPrecioSinIva);
            Controls.Add(lblDatos);
            Controls.Add(btnCalcular);
            Controls.Add(txtbxIva);
            Controls.Add(lblIva);
            Controls.Add(txtbxprecio);
            Controls.Add(lblprecio);
            Controls.Add(txtbxMarca);
            Controls.Add(lblMarca);
            Controls.Add(txtbxModelo);
            Controls.Add(lblModelo);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblModelo;
        private TextBox txtbxModelo;
        private Label lblMarca;
        private TextBox txtbxMarca;
        private Label lblprecio;
        private TextBox txtbxprecio;
        private Label lblIva;
        private TextBox txtbxIva;
        private Button btnCalcular;
        private Label lblDatos;
        private Label lblPrecioSinIva;
        private Label lblPrecioConIva;
        private Label lblMontoIva;
    }
}