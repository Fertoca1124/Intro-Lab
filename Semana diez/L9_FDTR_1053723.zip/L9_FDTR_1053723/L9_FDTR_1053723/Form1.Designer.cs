﻿namespace L9_FDTR_1053723
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblTipoCambio = new System.Windows.Forms.Label();
            this.txtbxModelo = new System.Windows.Forms.TextBox();
            this.txtbxPrecio = new System.Windows.Forms.TextBox();
            this.txtbxMarca = new System.Windows.Forms.TextBox();
            this.txtbxTIpoCambio = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.lblDescuento = new System.Windows.Forms.Label();
            this.txtbxDescuento = new System.Windows.Forms.TextBox();
            this.btnAplicarDescuento = new System.Windows.Forms.Button();
            this.lstboxInformacion = new System.Windows.Forms.ListBox();
            this.btnDisponibilidad = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(176, 57);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(320, 212);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnGuardar);
            this.tabPage1.Controls.Add(this.txtbxTIpoCambio);
            this.tabPage1.Controls.Add(this.txtbxMarca);
            this.tabPage1.Controls.Add(this.txtbxPrecio);
            this.tabPage1.Controls.Add(this.txtbxModelo);
            this.tabPage1.Controls.Add(this.lblTipoCambio);
            this.tabPage1.Controls.Add(this.lblMarca);
            this.tabPage1.Controls.Add(this.lblPrecio);
            this.tabPage1.Controls.Add(this.lblNombre);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(312, 186);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Datos obtenidos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnDisponibilidad);
            this.tabPage2.Controls.Add(this.lstboxInformacion);
            this.tabPage2.Controls.Add(this.btnAplicarDescuento);
            this.tabPage2.Controls.Add(this.txtbxDescuento);
            this.tabPage2.Controls.Add(this.lblDescuento);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(312, 186);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Datos Automovil";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(24, 21);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(42, 13);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Modelo";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(24, 53);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(37, 13);
            this.lblPrecio.TabIndex = 1;
            this.lblPrecio.Text = "Precio";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(24, 85);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(37, 13);
            this.lblMarca.TabIndex = 2;
            this.lblMarca.Text = "Marca";
            // 
            // lblTipoCambio
            // 
            this.lblTipoCambio.AutoSize = true;
            this.lblTipoCambio.Location = new System.Drawing.Point(24, 112);
            this.lblTipoCambio.Name = "lblTipoCambio";
            this.lblTipoCambio.Size = new System.Drawing.Size(81, 13);
            this.lblTipoCambio.TabIndex = 3;
            this.lblTipoCambio.Text = "Tipo de Cambio";
            // 
            // txtbxModelo
            // 
            this.txtbxModelo.Location = new System.Drawing.Point(67, 18);
            this.txtbxModelo.Name = "txtbxModelo";
            this.txtbxModelo.Size = new System.Drawing.Size(107, 20);
            this.txtbxModelo.TabIndex = 4;
            // 
            // txtbxPrecio
            // 
            this.txtbxPrecio.Location = new System.Drawing.Point(67, 50);
            this.txtbxPrecio.Name = "txtbxPrecio";
            this.txtbxPrecio.Size = new System.Drawing.Size(107, 20);
            this.txtbxPrecio.TabIndex = 5;
            // 
            // txtbxMarca
            // 
            this.txtbxMarca.Location = new System.Drawing.Point(67, 82);
            this.txtbxMarca.Name = "txtbxMarca";
            this.txtbxMarca.Size = new System.Drawing.Size(107, 20);
            this.txtbxMarca.TabIndex = 6;
            // 
            // txtbxTIpoCambio
            // 
            this.txtbxTIpoCambio.Location = new System.Drawing.Point(111, 108);
            this.txtbxTIpoCambio.Name = "txtbxTIpoCambio";
            this.txtbxTIpoCambio.Size = new System.Drawing.Size(107, 20);
            this.txtbxTIpoCambio.TabIndex = 7;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(105, 145);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(112, 29);
            this.btnGuardar.TabIndex = 8;
            this.btnGuardar.Text = "Guardar Informacion";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // lblDescuento
            // 
            this.lblDescuento.AutoSize = true;
            this.lblDescuento.Location = new System.Drawing.Point(17, 21);
            this.lblDescuento.Name = "lblDescuento";
            this.lblDescuento.Size = new System.Drawing.Size(59, 13);
            this.lblDescuento.TabIndex = 0;
            this.lblDescuento.Text = "Descuento";
            // 
            // txtbxDescuento
            // 
            this.txtbxDescuento.Location = new System.Drawing.Point(71, 18);
            this.txtbxDescuento.Name = "txtbxDescuento";
            this.txtbxDescuento.Size = new System.Drawing.Size(80, 20);
            this.txtbxDescuento.TabIndex = 1;
            // 
            // btnAplicarDescuento
            // 
            this.btnAplicarDescuento.Location = new System.Drawing.Point(167, 22);
            this.btnAplicarDescuento.Name = "btnAplicarDescuento";
            this.btnAplicarDescuento.Size = new System.Drawing.Size(86, 25);
            this.btnAplicarDescuento.TabIndex = 2;
            this.btnAplicarDescuento.Text = "Aplicar";
            this.btnAplicarDescuento.UseVisualStyleBackColor = true;
            this.btnAplicarDescuento.Click += new System.EventHandler(this.btnAplicarDescuento_Click);
            // 
            // lstboxInformacion
            // 
            this.lstboxInformacion.FormattingEnabled = true;
            this.lstboxInformacion.Location = new System.Drawing.Point(20, 53);
            this.lstboxInformacion.Name = "lstboxInformacion";
            this.lstboxInformacion.Size = new System.Drawing.Size(257, 82);
            this.lstboxInformacion.TabIndex = 3;
            // 
            // btnDisponibilidad
            // 
            this.btnDisponibilidad.Location = new System.Drawing.Point(84, 141);
            this.btnDisponibilidad.Name = "btnDisponibilidad";
            this.btnDisponibilidad.Size = new System.Drawing.Size(103, 34);
            this.btnDisponibilidad.TabIndex = 4;
            this.btnDisponibilidad.Text = "Cambiar Disponibilidad";
            this.btnDisponibilidad.UseVisualStyleBackColor = true;
            this.btnDisponibilidad.Click += new System.EventHandler(this.btnDisponibilidad_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.TextBox txtbxPrecio;
        private System.Windows.Forms.TextBox txtbxModelo;
        private System.Windows.Forms.Label lblTipoCambio;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox txtbxTIpoCambio;
        private System.Windows.Forms.TextBox txtbxMarca;
        private System.Windows.Forms.Button btnAplicarDescuento;
        private System.Windows.Forms.TextBox txtbxDescuento;
        private System.Windows.Forms.Label lblDescuento;
        private System.Windows.Forms.Button btnDisponibilidad;
        private System.Windows.Forms.ListBox lstboxInformacion;
    }
}

