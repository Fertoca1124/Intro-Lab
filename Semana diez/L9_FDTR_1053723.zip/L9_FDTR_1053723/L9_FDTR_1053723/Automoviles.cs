﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_FDTR_1053723
{
    internal class Automoviles
    {
        private int modelo;
        private double precio;
        private double tipoCambio;
        private string marca;
        private bool disponible;
        private double descuentoAplicado;

        public Automoviles()
        {
            this.modelo = 2019;
            this.precio = 10000;
            this.marca = "";
            this.disponible = false;
            this.tipoCambio = 7.50;
            this.descuentoAplicado = 0;
        }

        public void DefinirModelo(int unModelo)
        {
            this.modelo = unModelo;
        }
        public void DefinirPrecio(double unPrecio)
        {
            this.precio = unPrecio;
        }
        public void DefinirMarca(string unaMarca)
        {
            this.marca = unaMarca;
        }
        public void DefiniTipoCambio(double unTipoCambio)
        {
            this.tipoCambio = unTipoCambio;
        }
        public void CambiarDisponibilidad()
        {
            if (this.disponible == false)
            {
                this.disponible = true;
            }
            else
            {
                this.disponible = false;
            }
        }

        public string MostrarDisponibilidad()
        {
            if (this.disponible == false)
            {
                return "No Disponible";
            }
            else
            {
                return "Disponible";
            }
        }

        public string MostrarInformacion()
        {
            string message = "";
            message = "Marca: " + marca + ". Modelo: " + Convert.ToString(modelo) + ". Precio de venta: Q" + Convert.ToString(precio) + ". Precio en dolares $" + Convert.ToString(precio / tipoCambio) + ". " + MostrarDisponibilidad();
            return message;
        }
        public void AplicarDescuento(double miDescuento)
        {
            this.descuentoAplicado = miDescuento;
            double descuento = this.precio * this.descuentoAplicado;
            double precio = this.precio - descuento;
            this.DefinirPrecio(precio);
        }
    }
}


