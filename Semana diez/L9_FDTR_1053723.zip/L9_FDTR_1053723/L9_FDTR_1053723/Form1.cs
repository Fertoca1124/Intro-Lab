﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_FDTR_1053723
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Automoviles objAutomovil = new Automoviles();

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int modelo;
            double precio, tipocambio;
            string marca;

            modelo = int.Parse(txtbxModelo.Text);
            precio = double.Parse(txtbxPrecio.Text);
            tipocambio = double.Parse(txtbxTIpoCambio.Text);
            marca = txtbxMarca.Text;

            objAutomovil.DefinirMarca(marca);
            objAutomovil.DefinirModelo(modelo);
            objAutomovil.DefinirPrecio(precio);
            objAutomovil.DefiniTipoCambio(tipocambio);

            lstboxInformacion.Items.Clear();
            lstboxInformacion.Items.Add(objAutomovil.MostrarInformacion());
        }

        private void btnAplicarDescuento_Click(object sender, EventArgs e)
        {
            double descuento = double.Parse(txtbxDescuento.Text) / 100;
            objAutomovil.AplicarDescuento(descuento);
            lstboxInformacion.Items.Clear();
            lstboxInformacion.Items.Add(objAutomovil.MostrarInformacion());

        }

        private void btnDisponibilidad_Click(object sender, EventArgs e)
        {
            objAutomovil.CambiarDisponibilidad();
            lstboxInformacion.Items.Clear();
            lstboxInformacion.Items.Add(objAutomovil.MostrarInformacion());
        }
    }

}



