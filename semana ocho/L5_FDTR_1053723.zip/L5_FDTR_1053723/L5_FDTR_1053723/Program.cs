﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_FDTR_1053723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 1//
            Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingresar un numeró entero");

            int numero = Convert.ToInt32(Console.ReadLine());

            if (numero > 0) 
            {
             Console.WriteLine("El valor es positivo");
            }

            else if (numero < 0) 
            {
            Console.WriteLine("El valor en negativo");
            }

            else if (numero == 0)
            {
            Console.WriteLine("El valor es igual a 0");
            }

            Console.ReadKey();

            Console.Clear();

            //Ejercicio 2//
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Ingresar el número de día");

            int número = Convert.ToInt32(Console.ReadLine());

            if (número > 7) 
            {
                Console.WriteLine("“Error: El número a ingresar debe estar contenido entre 1 y 7");
            }

            else if (número < 0) 
            {
                Console.WriteLine("“Error: El número a ingresar debe estar contenido entre 1 y 7");
            }

            else if (número == 1)
            {
                Console.WriteLine("Lunes");
            }

            else if (número == 2)
            {
                Console.WriteLine("Martes");
            }

            else if (número == 3)
            {
                Console.WriteLine("Miercoles");
            }

            else if (número == 4)
            {
                Console.WriteLine("Jueves");
            }

            else if (número == 5)
            {
                Console.WriteLine("Viernes");
            }

            else if (número == 6)
            {
                Console.WriteLine("Sabado");
            }

            else if (número == 7)
            {
                Console.WriteLine("Jueves");
            }

            Console.ReadKey();

        }
    }
}
