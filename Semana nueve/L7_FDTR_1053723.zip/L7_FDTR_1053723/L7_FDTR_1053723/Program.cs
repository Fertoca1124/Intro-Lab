﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L7_FDTR_1053723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;

            bool n1;
            do
            {
                Console.Write("Ingrese un número entero mayor que 0: ");
                string input = Console.ReadLine();
                n1 = int.TryParse(input, out n);

                if (!n1 || n <= 0)
                {
                    Console.WriteLine("Por favor, ingrese un número entero válido mayor que 0.");
                }

            } while (!n1 || n <= 0);

        
            int a = 0, b = 1;
            int count = 0;

            Console.WriteLine("Posiciones de la sucesión de Fibonacci hasta el término " + n + ":");
            while (count < n)
            {
                Console.Write(a + " "); 

                int c = a + b;
                a = b; 
                b = c; 

                count++; 
            }

            Console.ReadKey();

        }
    }
}
