﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T7_FDTR_1053723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, x, a;

            
            Console.Write("Ingrese un número entero mayor que 0 para 'n': ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.WriteLine("Por favor, ingrese un número entero válido mayor que 0.");
                Console.Write("Ingrese un número entero mayor que 0 para 'n': ");
            }

            
            Console.Write("Ingrese un número entero para 'x': ");
            x = int.Parse(Console.ReadLine());

            
            Console.Write("Ingrese un número entero para 'a': ");
            a = int.Parse(Console.ReadLine());

            
            double sumaA = 0;
            int i = 1;
            while (i <= n)
            {
                sumaA += 1.0 / i;
                i++;
            }

            double sumaB = 0;
            i = 1;
            while (i <= n)
            {
                sumaB += 1.0 / Math.Pow(2, i);
                i++;
            }
            
            double sumaC = 0;
            int k = 0;
            while (k <= n)
            {
                sumaC += Math.Pow(x, k) * Math.Pow(a, n - k) / Math.Pow(n, k);
                k++;
            }

            Console.WriteLine($"La serie a es: {sumaA}");
            Console.WriteLine($"La serie b es: {sumaB}");
            Console.WriteLine($"La serie c es: {sumaC}");

            Console.ReadKey();
        }

        

    }
    }

