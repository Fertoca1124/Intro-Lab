﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_FDTR_1053723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double opción1 = 0;
            double opción2 = 0;
            double opción3 = 0;
            double quetzales1 = 0;
            double quetzales2 = 0;
            double quetzales3 = 0;
            double dolares1 = 0;
            double dolares2 = 0;
            double dolares3 = 0;

            Console.WriteLine("Favor seleccionar una opción del tipo de mondeada en la primera cantidad");
            Console.WriteLine("1. GTQ");
            Console.WriteLine("2. USD");

            opción1 = Convert.ToInt32(Console.ReadLine());

            if (opción1 == 1)
            {
                Console.WriteLine("Ingresar la cantidad de diniero en GTQ");
                quetzales1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Su cantidad es " + quetzales1);
            }

            else if (opción1 == 2)
            {
                Console.WriteLine("Ingresar la cantidad de dinero en USD");
                dolares1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Su cantidad es " + dolares1);
                quetzales1 = dolares1 * 7.83;
                Console.WriteLine("Su cantidad es " + quetzales1);
            }

            Console.WriteLine("Favor seleccionar una opción del tipo de mondeada en la segunda cantidad");
            Console.WriteLine("1. GTQ");
            Console.WriteLine("2. USD");
            opción2 = Convert.ToInt32(Console.ReadLine());

            if (opción2 == 1)
            {
                Console.WriteLine("Ingresar la cantidad de dinero en GTQ");
                quetzales2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Su cantidad es " + quetzales2);
            }

            else if (opción2 == 2)
            {
                Console.WriteLine("Ingresar la cantidad de dinero en USD");
                dolares2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Su cantidad es " + dolares2);
                quetzales2 = dolares2 * 7.83;
                Console.WriteLine("Su cantidad es " + quetzales2);
            }

            Console.WriteLine("Favor seleccionar una opción del tipo de mondeada en la tercera cantidad");
            Console.WriteLine("1. GTQ");
            Console.WriteLine("2. USD");
            opción3 = Convert.ToInt32(Console.ReadLine());

            if (opción3 == 1)
            {
                Console.WriteLine("Ingresar la cantisas de dinero en GTQ");
                quetzales3 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Su cantidad es " + quetzales3);
            }

            else if (opción3 == 2)
            {
                Console.WriteLine("Ingresar la cantidad de dinero en USD");
                dolares3 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Su cantidad es " + dolares3);
                quetzales3 = dolares3 * 7.83;
                Console.WriteLine("Su cantidad es " + quetzales3);
            }

            Console.WriteLine("Orden ascendente");

            if (quetzales1 > quetzales2 && quetzales3 < quetzales1)
            {
                if (quetzales3 < quetzales2)
                {
                    Console.WriteLine(quetzales1);
                    Console.WriteLine(quetzales2);
                    Console.WriteLine(quetzales3);
                }
            }
             if (quetzales2 > quetzales1 && quetzales2 > quetzales3)
            {
                if (quetzales1 < quetzales3)
                {
                    Console.WriteLine(quetzales2);
                    Console.WriteLine(quetzales3);
                    Console.WriteLine(quetzales1);
                }
            }
            if (quetzales3 > quetzales1 && quetzales3 > quetzales2)
            {
                if (quetzales1 < quetzales2)
                {
                    Console.WriteLine(quetzales3);
                    Console.WriteLine(quetzales2);
                    Console.WriteLine(quetzales1);
                }
            }
            if (quetzales1 > quetzales3 && quetzales1 > quetzales2)
            {
                if (quetzales1 < quetzales3)
                {
                    Console.WriteLine(quetzales1);
                    Console.WriteLine(quetzales3);
                    Console.WriteLine(quetzales2);
                }
            }
            if (quetzales3 > quetzales1 && quetzales3 > quetzales2)
            {
                if (quetzales2 < quetzales1)
                {
                    Console.WriteLine(quetzales3);
                    Console.WriteLine(quetzales1);
                    Console.WriteLine(quetzales2);
                }
            }
            if (quetzales2 > quetzales1 && quetzales2 > quetzales3)
            {
                if (quetzales3 < quetzales2)
                {
                    Console.WriteLine(quetzales2);
                    Console.WriteLine(quetzales1);
                    Console.WriteLine(quetzales3);
                }
            }
                     
            Console.ReadKey();
            }
        }
    }


